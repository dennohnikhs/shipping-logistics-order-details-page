import { Component } from "@angular/core";

@Component({
  selector: "app-shipping-logistics-product-information",
  standalone: true,
  imports: [],
  templateUrl: "./shipping-logistics-product-information.component.html",
  styleUrl: "./shipping-logistics-product-information.component.scss",
})
export class ShippingLogisticsProductInformationComponent {}
