import { Component } from "@angular/core";

@Component({
  selector: "order-shipping-details-header",
  standalone: true,
  imports: [],
  templateUrl: "./product-post.component.html",
  styleUrl: "./product-post.component.scss",
})
export class OrderShippingDetailsHeaderComponent {}
