import { Component } from "@angular/core";

@Component({
  selector: "app-shipping-logistics-order-information",
  standalone: true,
  imports: [],
  templateUrl: "./shipping-logistics-order-information.component.html",
  styleUrl: "./shipping-logistics-order-information.component.scss",
})
export class ShippingLogisticsOrderInformationComponent {}
